﻿using BankSystem.Client.ClientStatus;
namespace BankSystem.Client.ClientFee;

public class Fee : IFee
{
    public decimal GetFee(ClientInfo client)
    {
        decimal fee = 0;
        switch (client.Status)
        {
            case StatusList.Regular:
                fee = 0.5M;
                break;
            case StatusList.Business:
                fee = 0.3M;
                break;
            case StatusList.Prime:
                fee = 0.1M;
                break;
        }
        return fee;
    }
}
