﻿using BankSystem.Client;
namespace BankSystem.ChainOfResp;

public class PinValidator : Validator
{
    public override void Validate(ClientInfo client, int pin, decimal amount)
    {
        if (client.Pin != pin)
        {
            _consoleLog.Log($"Client {client.Name} entered wrong PIN");
            _fileLog.Log($"Client {client.Name} entered wrong PIN");
            return;
        }
        _super?.Validate(client, pin, amount);
    }
}
