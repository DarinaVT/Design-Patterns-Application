﻿namespace BankSystem.Logger;

public class Data : ILogger
{
    private readonly ILogger _consoleLogger;
    private readonly ILogger _fileLogger;
    public void Log(string message)
    {
        _consoleLogger.Log(message);
        _fileLogger.Log(message);
    }
}
