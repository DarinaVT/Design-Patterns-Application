﻿using BankSystem.Client;
using BankSystem.Client.ClientFee;
namespace BankSystem.ChainOfResp;

public class BalanceValidator : Validator
{
    private Fee _fee;
    public override void Validate(ClientInfo client, int pin, decimal amount)
    {
        string message;
        if (client.Balance < amount + _fee.GetFee(client))
        {
            message = $"Client {client.Name} has an issufficient balance";
        }
        else
        {
            message = $"Client {client.Name} has enough money to draw {amount}";
            if (_super != null)
            {
                _super.Validate(client, pin, amount);
            }
        }
        Result(message);
    }
    public string Result(string message)
    {
        return message;
    }
}
