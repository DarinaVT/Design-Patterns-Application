﻿namespace BankSystem.Command;

public interface ICommand
{
    void Execute();
}
