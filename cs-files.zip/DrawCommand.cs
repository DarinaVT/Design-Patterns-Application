﻿using BankSystem.ChainOfResp;
namespace BankSystem.Command;

public class DrawCommand : ICommand
{
    private Transaction _transaction;
    private Validator _validator;

    public DrawCommand(Transaction transaction, Validator validator)
    {
        _transaction = transaction;
        _validator = validator;
    }
    public void Execute()
    {
        if (_validator.Validate(_transaction.Client, _transaction.Pin, _transaction.Amount))
        {

        }
    }
}
