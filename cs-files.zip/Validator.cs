﻿using BankSystem.Client;
using BankSystem.Logger;
namespace BankSystem.ChainOfResp;

public abstract class Validator
{
    protected readonly ILogger _consoleLog;
    protected readonly ILogger _fileLog;
    protected Validator _super;
    public void SetSuper(Validator super)
    {
        _super = super;
    }
    public abstract void Validate(ClientInfo client, int pin, decimal amount);
    public abstract string Result(string message);
}
