﻿using BankSystem.Logger;
namespace BankSystem;

public class Engine
{
    private Data _logger;
    public void Run()
    {
        _logger.Log("this");
    }
}
